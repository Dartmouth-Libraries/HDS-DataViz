library(testthat)

library(doBy)
test_check("doBy")


