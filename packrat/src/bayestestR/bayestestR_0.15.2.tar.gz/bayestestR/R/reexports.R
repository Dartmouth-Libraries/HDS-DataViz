# DO NOT REMOVE
# Re-exported generics for which the current package defines S3 methods

#' @importFrom insight print_html
#' @export
insight::print_html

#' @importFrom insight print_md
#' @export
insight::print_md
