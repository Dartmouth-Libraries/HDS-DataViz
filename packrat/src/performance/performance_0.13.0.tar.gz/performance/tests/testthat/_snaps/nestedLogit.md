# model_performance

    Code
      model_performance(mnl)
    Output
      # Indices of model performance
      
      Response |     AIC |     BIC |  RMSE | Sigma |    R2
      ----------------------------------------------------
      work     | 325.733 | 336.449 | 0.456 | 1.000 | 0.138
      full     | 110.495 | 118.541 | 0.398 | 1.000 | 0.333

