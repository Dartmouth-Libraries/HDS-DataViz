# check_outliers.rma

    Code
      out
    Output
      2 outliers detected: studies 4 (Hart & Sutherland) and 8 (TPT Madras).

