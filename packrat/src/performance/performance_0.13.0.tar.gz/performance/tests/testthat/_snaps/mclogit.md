# model_performance

    Code
      model_performance(mod_mb)
    Output
      # Indices of model performance
      
      AIC    |    BIC | Nagelkerke's R2 |  RMSE | Sigma
      -------------------------------------------------
      38.823 | 47.618 |           0.836 | 0.298 | 1.016

---

    Code
      model_performance(mod_mc)
    Output
      # Indices of model performance
      
      AIC    |    BIC | Nagelkerke's R2 |  RMSE | Sigma
      -------------------------------------------------
      13.228 | 24.424 |           0.998 | 0.009 | 0.068

