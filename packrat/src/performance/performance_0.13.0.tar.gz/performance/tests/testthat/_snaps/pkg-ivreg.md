# Issue #530 from the `modelsummary` repo

    Code
      out
    Output
      # Indices of model performance
      
      AIC     |     BIC |    R2 | R2 (adj.) |  RMSE | Sigma | Wu & Hausman
      --------------------------------------------------------------------
      182.692 | 191.486 | 0.655 |     0.604 | 3.484 | 3.793 |       13.869
      
      AIC     | p (Wu_Hausman) | Weak instruments | p (weak_instruments)
      ------------------------------------------------------------------
      182.692 |         < .001 |           19.958 |               < .001

