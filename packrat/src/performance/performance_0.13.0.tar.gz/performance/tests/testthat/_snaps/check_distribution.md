# check_distribution

    Code
      print(out)
    Output
      # Distribution of Model Family
      
      Predicted Distribution of Residuals
      
                     Distribution Probability
                           cauchy         91%
                            gamma          6%
       neg. binomial (zero-infl.)          3%
      
      Predicted Distribution of Response
      
       Distribution Probability
          lognormal         66%
              gamma         34%

