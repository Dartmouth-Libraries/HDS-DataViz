# bootstrapped icc ci_methods

    Code
      print(out1)
    Output
      # Intraclass Correlation Coefficient
      
          Adjusted ICC: 0.722 [0.502, 0.794]
        Unadjusted ICC: 0.521 [0.310, 0.568]

---

    Code
      print(out2)
    Output
      # Intraclass Correlation Coefficient
      
          Adjusted ICC: 0.722 [0.647, 0.886]
        Unadjusted ICC: 0.521 [0.474, 0.657]

---

    Code
      print(out3)
    Output
      # Intraclass Correlation Coefficient
      
          Adjusted ICC: 0.722 [0.644, 0.783]
        Unadjusted ICC: 0.521 [0.412, 0.615]

# bootstrapped r2_nakagawa ci_methods

    Code
      print(out1)
    Output
      # R2 for Mixed Models
      
        Conditional R2: 0.799 [0.678, 0.852]
           Marginal R2: 0.279 [0.204, 0.392]

---

    Code
      print(out2)
    Output
      # R2 for Mixed Models
      
        Conditional R2: 0.799 [0.734, 0.918]
           Marginal R2: 0.279 [0.231, 0.309]

---

    Code
      print(out3)
    Output
      # R2 for Mixed Models
      
        Conditional R2: 0.799 [0.739, 0.846]
           Marginal R2: 0.279 [0.170, 0.390]

