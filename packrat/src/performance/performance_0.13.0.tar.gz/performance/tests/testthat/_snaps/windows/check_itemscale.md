# check_itemscale

    Code
      print(out)
    Output
      # Description of (Sub-)ScalesComponent 1
      
      Item | Missings | Mean |   SD | Skewness | Difficulty | Discrimination | alpha if deleted
      -----------------------------------------------------------------------------------------
      b    |        0 | 5.02 | 0.79 |    -0.04 |       0.84 |           0.06 |            -0.55
      e    |        0 | 2.12 | 0.81 |    -0.22 |       0.35 |          -0.09 |            -0.03
      f    |        0 | 2.00 | 0.82 |     0.00 |       0.33 |          -0.16 |             0.17
      
      Mean inter-item-correlation = -0.046  Cronbach's alpha = -0.159
      Component 2
      
      Item | Missings | Mean |   SD | Skewness | Difficulty | Discrimination | alpha if deleted
      -----------------------------------------------------------------------------------------
      a    |        0 | 5.02 | 0.83 |    -0.04 |       0.84 |           0.21 |            -0.18
      c    |        0 | 4.74 | 0.81 |     0.51 |       0.79 |          -0.04 |             0.41
      d    |        0 | 2.07 | 0.79 |    -0.13 |       0.34 |           0.13 |             0.04
      
      Mean inter-item-correlation = 0.067  Cronbach's alpha = 0.178

