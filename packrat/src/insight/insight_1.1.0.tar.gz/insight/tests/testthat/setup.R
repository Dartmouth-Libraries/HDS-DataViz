if (requireNamespace("httptest2")) {
  library(httptest2)
}
