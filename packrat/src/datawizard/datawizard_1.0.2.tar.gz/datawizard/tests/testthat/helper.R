if (insight::check_if_installed("poorman", stop = FALSE)) {
  `%>%` <- poorman::`%>%`
}
