# smoothness works with data frames

    Code
      smoothness(BOD)
    Output
             Parameter                    
      Time   "Time"    "0.986393923832144"
      demand "demand"  "0.406270770677043"
      attr(,"class")
      [1] "parameters_smoothness" "matrix"                "array"                

